<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator;
use App\Models\Admin;
use App\Models\User;
use Auth;

class LoginController extends Controller
{
          // i use it in tinker
        //    public function save() {
        //        $admin = new App\Models\Admin();
        //        $admin->name = "Abdelazem Abdelhamed";
        //        $admin->email = "abdelazem15181996@gmail.com";
        //        $admin->password = bcrypt("12345678");
        //        $admin->save();
        //    }

        public function getRegister() {

           return view('admin.auth.register');
        }

        public function storeRegister(Request $request)  {


        //     dd($request->all());
            $validator = Validator::make($request->all(),[
                  'email'   => 'required|email|unique:users',
                  'password' => 'required|confirmed',
                  'image'    => 'required',
                  'user_name' => 'required|unique:users',

                ]);




           if ($validator->fails()) {
               return redirect()->back()->with(array('errors' => $validator->getMessageBag()));
           }


               //--- Validation Section Ends

                $user = new User;

                if ($request->hasFile('image') && !empty($request->hasFile('image'))) {
                       $image = $request->file('image');
                       $image_ext = $image->getClientOriginalExtension();
                       $path = rand(123456, 999999) . "." . $image_ext;
                       $destination_path = public_path('assets/images/users/');
                       $image->move($destination_path, $path);
                       $input['image'] = $path;

                }

                        $user->first_name = $request->first_name;
                        $user->last_name = $request->last_name;
                        $user->user_name = $request->user_name;
                        $user->email = $request->email;
                        $user->password =  bcrypt($request->password);
                        $user->image = $path;
                        $user->save();

               //    $to = $request->email;
        	     // $subject = 'Pripo User Name And Password';
        	     // $msg = "User Name : ". $request->user_name . "<br> Your Password : " . $request->email;
               //
               //   \Mail::send('verfiy_emial',
               //       array(
               //
               //           'msg' => $msg,
               //
               //       ), function($message) use ($request)
               //        {
               //            $message->from('pripo@germaniatek.co');
               //            $message->to($request->email);
               //        });
               //
                // Auth::guard('admin')->login($user);
                return redirect() -> route('admin.dashboard')->with(['success' => 'Data Added Successfully']);

}


       public function profileupdate(Request $request)  {

           $id = auth()->user()->id;

         //  dd($id);
          //  dd($request->all());
            $validator = Validator::make($request->all(),[
                  'user_name'   => 'required|unique:users,user_name,'.$id,

            ]);




          if ($validator->fails()) {
              return redirect()->back()->with(array('errors' => $validator->getMessageBag()));
          }


               //--- Validation Section Ends

                $user =  User::find($id);

                if ($request->hasFile('image') && !empty($request->hasFile('image'))) {
                       $image = $request->file('image');
                       $image_ext = $image->getClientOriginalExtension();
                       $path = rand(123456, 999999) . "." . $image_ext;
                       $destination_path = public_path('assets/images/users/');
                       $image->move($destination_path, $path);
                       $user->image = $path;

                }

                        $user->first_name = $request->first_name;
                        $user->last_name = $request->last_name;
                        $user->user_name = $request->user_name;
                        $user->email = $request->email;
                        if(!empty($request->password)) {
                        $user->password =  bcrypt($request->password);
                        }else{
                               $user->password =  bcrypt(auth()->user()->password);
                        }

                       $user->save();
              

                // Auth::guard('admin')->login($user);
                return redirect() -> route('admin.dashboard')->with(['success' => 'Data Updated Successfully']);;

}


        public function getLogin() {

           return view('admin.auth.login');
        }
        public function Login(Request $request){

          //if he click remeber me make it true
          $remember_me = $request->has('remember_me') ? true : false;

          $this->validate($request, [


                        'user_name'                     => 'required',


           ]);

        // dd($request->email);


          if (auth()->guard('admin')->attempt(['user_name' => $request->input("user_name"), 'password' => $request->input("password")], $remember_me)) {
              // notify()->success('تم الدخول بنجاح  ');
              return redirect() -> route('admin.dashboard');
          }
          // notify()->error('خطا في البيانات  برجاء المجاولة مجدا ');
          return redirect()->back()->with(['error' => 'هناك خطا بالبيانات']);
        }


            public function logout()
       {
           Auth::guard('admin')->logout();
           return redirect('/admin');
       }
}
