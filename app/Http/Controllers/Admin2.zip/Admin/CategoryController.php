<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Task;
use App\Models\Log;
use DataTables;
use DB;
use Validator;
use Auth;
class CategoryController extends Controller
{
   public function index() {
        $datas = Category::orderBy('id','desc')->get();
        return view('admin.categories.index',compact('datas'));
    }

    public function create() {
      return view('admin.categories.create');
   }

   public function store(Request $request) {

       try {
         $validator = Validator::make($request->all(),[
               'category_name' => 'required|string',
               'category_color' => 'required',
         ]);

         if ($validator->fails()) {
             return redirect()->back()->with(array('errors' => $validator->getMessageBag()));
         }
          DB::beginTransaction();
          $data = new Category();
          $data->category_name = $request->category_name;
          $data->category_color = $request->category_color;
          $data->save();
          $log = new Log();
          $log->log_desc = "The User ".Auth::user()->user_name .' Add A New Category ' . $data->category_name ;
          $log->log_user_id = Auth::user()->id;
          $log->log_cat_id = $data->id;
          $log->save();
          DB::commit();
         return redirect()->route('admin.categories')->with(['success' => 'Data Added Successfully']);
       }catch(Exception $e) {
           return redirect()->route('admin.categories')->with(['error' => 'Something Wrong Happen']);
       }


   }
   public function edit(Request $request ) {
           $id     = $request->id;
           $category  = Category::find($id);
           return view('admin.categories.edit', ['category' => $category,'id' => $id]);
    }
   public function update(Request $request , $id) {
         try {
             $validator = Validator::make($request->all(),[
                   'category_name' => 'required|string',
             ]);

               if ($validator->fails()) {
                   return redirect()->route('admin.categories.edit')->with(array('errors' => $validator->getMessageBag()));
               }
              DB::beginTransaction();
              $data =Category::find($id);
              $data->category_name = $request->category_name;
              $data->category_color = $request->category_color;
              $data->save();
              $log = new Log();
              $log->log_desc = "The User ".Auth::user()->user_name .' Updated The Category ' . $data->category_name ;
              $log->log_user_id = Auth::user()->id;
              $log->log_cat_id = $id;
              $log->save();
              DB::commit();
             return redirect()->route('admin.categories')->with(['success' => 'Data Updated Successfully']);
           }catch(Exception $e) {
               return redirect()->route('admin.categories')->with(['error' => 'Something Wrong Happen']);
           }

  }
  public function delete(Request $request) {
        $id = $request->id;
        $tasks = Task::where('task_category_id' , $id)->get();

        if(!empty($tasks) && count($tasks) >0) {

          $msg = 'Deleted All Tasks Related To This Cstegory First';
          return response()->json([
                     "status" =>  false,
                     "msg" => $msg
                     ],200);
         }
       else {
        $data = Category::find($id);
        $log = new Log();
        $log->log_desc = "The User ".Auth::user()->user_name .' Deleted The Category ' . $data->category_name ;
        $log->log_user_id = Auth::user()->id;
        $log->log_cat_id = $id;
        $data->delete();
        $log->save();
        $msg = 'Data Deleted Successfully';
        return response()->json([
                   "status" =>  true,
                   "msg" => $msg
                   ],200);

          }
       }
}
