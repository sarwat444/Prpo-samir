<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Category;
use App\Models\Task;
use App\Models\TaskTeam;
class DashboardController extends Controller
{
      public function index(){
         $tasks = Task::orderBy('task_priority' , 'asc')->get();
         $categories = Category::all();
         return view('admin.dashboard',compact('tasks','categories'));
     }
     public function filterByCategory(Request $request) {
          if(!empty($request->id)){
                  
                   if($request->id == "all"){
                        $tasks = Task::orderBy('task_priority' , 'asc')->get(); 
                   }else {
                     $tasks = Task::where('task_category_id',$request->id)->orderBy('task_priority' , 'asc')->get();      
                   }
                  
                  $data = view('admin.tasks.filter_by_category',compact('tasks'))->render();
                  return response()->json(['options'=>$data]);
          }
     }
}
