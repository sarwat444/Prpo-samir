<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\SubTask;
use App\Models\User;
use App\Models\TaskTeam;
use App\Models\Category;
use App\Models\Log;
use DataTables;
use DB;
use Validator;
use Auth;

class TasksController extends Controller
{
  public function index() {
       $datas = Task::orderBy('task_priority')->get();
       return view('admin.tasks.index',compact('datas'));
   }

   public function create() {
     $users = User::all();
     $categories = Category::all();
     return view('admin.tasks.create',compact('users','categories'));
  }

  public function store(Request $request) {

      try {
        $validator = Validator::make($request->all(),[
              'task_title' => 'required|string|max:60',
              'task_desc' => 'required',
              'task_category_id' => 'required',
              'task_responsible' => 'required',
              'task_start_date' => 'required',
              'task_due_date' => 'required',

        ]);

          // if ($validator->fails()) {
          //     return redirect()->route('admin.tasks.create')->with(array('errors' => $validator->getMessageBag()));
          // }
         DB::beginTransaction();
         $data = new Task();
         $data->task_title = $request->task_title;
         $data->task_desc = $request->task_desc;
         $data->task_category_id = $request->task_category_id;
         $data->task_added_by = Auth::user()->id;
         $data->task_responsible = $request->task_responsible;
         $data->task_start_date = $request->task_start_date;
         $data->task_due_date = $request->task_due_date;
         $data->save();
         $inserted_id   =    $data->id;
         $data->task_priority = $inserted_id;
         $data->save();
         if(!empty($request->teams_id)) {
                     $interest_array = $request->teams_id;
                     $array_len = count($interest_array);
                     for ($i = 0; $i < $array_len; $i++) {

                               if($interest_array[$i] == Auth::user()->id || $interest_array[$i] == $request->task_responsible){
                                  continue;
                               }else {
                               $dta = new TaskTeam();
                               $dta->user_id = $interest_array[$i];
                               $dta->task_id = $inserted_id;
                               $dta->save();
                             }
                       }
          }

          $log = new Log();
          $log->log_desc = "The User ".Auth::user()->user_name .' Add A New Task ' . $data->task_title ;
          $log->log_user_id = Auth::user()->id;
          $log->log_task_id = $data->id;
          $log->save();

         DB::commit();
         return redirect()->route('admin.dashboard')->with(['success' => 'Data Added Successfully']);
      }catch(Exception $e) {
          return redirect()->route('admin.dashboard')->with(['error' => 'Something Wrong Happen']);
      }


  }
  public function edit(Request $request ) {
          $id     = $request->id;
          $data  = Task::find($id);
          $users = User::all();
          $categories = Category::all();
          return view('admin.tasks.edit', ['data' => $data,'id' => $id , 'users' => $users , 'categories' => $categories ]);
   }
  public function update(Request $request , $id) {
    try {
      $validator = Validator::make($request->all(),[
            'task_title' => 'required|string|max:60',
            'task_desc' => 'required',
            'task_category_id' => 'required',
            'task_responsible' => 'required',
           // 'task_start_date' => 'required',
            'task_due_date' => 'required',

      ]);

        // if ($validator->fails()) {
        //     return redirect()->route('admin.tasks.create')->with(array('errors' => $validator->getMessageBag()));
        // }
       DB::beginTransaction();
             $data =Task::find($id);
             $data->task_title = $request->task_title;
             $data->task_desc = $request->task_desc;
             $data->task_category_id = $request->task_category_id;
             $data->task_responsible = $request->task_responsible;
           //  $data->task_start_date = $request->task_start_date;
             $data->task_due_date = $request->task_due_date;

             $data->save();
             if(!empty($request->teams_id)) {
                 
                TaskTeam::where('task_id',$id)->delete();
               $interest_array = $request->teams_id;
               
               $array_len = count($interest_array);
              for ($i = 0; $i < $array_len; $i++) {

                if($interest_array[$i] == Auth::user()->id || $interest_array[$i] == $request->task_responsible){
                   continue;
                }else {
                       $pres = TaskTeam::where('task_id',$id)->where('user_id',$interest_array[$i])->first();

                        if(!empty($pres)) {
                          continue;
                        }else {
                         $dta = new TaskTeam();

                          $dta->user_id = $interest_array[$i];
                          $dta->task_id = $id;
                          $dta->save();
                        }
                    }

                 }


              }

              $log = new Log();
              $log->log_desc = "The User ".Auth::user()->user_name .' Updated The Task ' . $data->task_title ;
              $log->log_user_id = Auth::user()->id;
              $log->log_task_id = $id;
              $log->save();
             DB::commit();
            return redirect()->route('admin.dashboard')->with(['success' => 'Data Updated Successfully']);
          }catch(Exception $e) {
              return redirect()->route('admin.dashboard')->with(['error' => 'Something Wrong Happen']);
          }

 }
 public function delete(Request $request) {
       $id = $request->id;
       $data = Task::find($id);
       $log = new Log();
       $log->log_desc = "The User ".Auth::user()->user_name .' Deleted The Task ' . $data->task_title ;
       $log->log_user_id = Auth::user()->id;
       $log->log_task_id = $id;
       $data->delete();
       $log->save();
       $msg = 'Data Deleted Successfully';
       return response()->json([
                  "status" =>  true,
                  "msg" => $msg
                  ],200);
    }

  public function updateStatus($id) {
          $data =Task::find($id);
          if($data->task_status == 0) {
                $data->task_status = 1;
                $log = new Log();
                $log->log_desc = "The User ".Auth::user()->user_name .' Make The Task ' . $data->task_title . ' Completed';
                $log->log_user_id = Auth::user()->id;
                $log->log_task_id = $id;

          }else {
             $data->task_status = 0;
             $log = new Log();
             $log->log_desc = "The User ".Auth::user()->user_name .' Make The Task ' . $data->task_title . ' InCompleted';
             $log->log_user_id = Auth::user()->id;
             $log->log_task_id = $id;

          }
          $data->save();
          $log->save();
  }

    public function showTaskData(Request $request) {
                $id     = $request->id;
                $task =Task::find($id);
                $subtasks =SubTask::where('task_id' , $id)->get();
                $users = User::all();
                $teamids = TaskTeam::where('task_id' , $id)->pluck('user_id');
                $teams   =  User::whereIn('id',$teamids)->get();
                $cats = Category::all();
                return view('admin.tasks.popup', ['task' => $task,'users' => $users,'teams' => $teams ,'subtasks' => $subtasks ,'cats' => $cats , 'id' => $id]);
    }
      
      // getCreateView
      
       public function getCreateView(Request $request) {
                $type     = $request->type;
                $users = User::all();
                $categories = Category::all();
                return view('admin.tasks.'.$type ,  ['users' => $users,'categories' => $categories]);
     }
     
     
     //set perority 
     
     public  function sorting(Request $request)
     {
         
         
         $perorityList = $request->all() ; 
  
         if($request->isMethod('POST')){
             
             
            
             

             foreach($request->list as $key => $taksId){
                    
                     $d = Task::find($taksId);

                     if(!empty($d)) {
                     $d->task_priority = $key;
                     
                     $d->save();

                 }
                 

             }
             
       
          
         }
     }
     
    public function updateTaskfield(Request $request) {
         //  dd($request->all());
            DB::beginTransaction();
            
            $id = $request->task_id;
            $data =Task::find($id);
            
            $cat_id = $data->task_category_id;
            
            if($request->field_name == 'teams_id') {
              //   dd($request->field_val);
              if(!empty($request->field_val)) {
                    TaskTeam::where('task_id',$id)->delete();
                  $interest_array = $request->field_val;
                  $array_len = count($interest_array);
              for ($i = 0; $i < $array_len; $i++) {

                 if($interest_array[$i] == Auth::user()->id || $interest_array[$i] == $data->task_responsible){
                       continue;
                  }else {
                          $pres = TaskTeam::where('task_id',$id)->where('user_id',$interest_array[$i])->first();
                        if(!empty($pres)) {
                          continue;
                        }else {
                         $dta = new TaskTeam();

                          $dta->user_id = $interest_array[$i];
                          $dta->task_id = $id;
                          $dta->save();
                        }
                  }

                }

                  $log = new Log();
                  $log->log_desc = "The User ".Auth::user()->user_name .' Updated Team Members in  The Task ' . $data->task_title ;
                  $log->log_user_id = Auth::user()->id;
                  $log->log_task_id = $id;
                  $log->save();
             
             }else {
                    TaskTeam::where('task_id',$id)->delete();
                      $log = new Log();
                  $log->log_desc = "The User ".Auth::user()->user_name .' Updated All Team Members in  The Task ' . $data->task_title ;
                  $log->log_user_id = Auth::user()->id;
                  $log->log_task_id = $id;
                  $log->save();
             }
              
                 
                 
            }else {
                
                
                
                
                $field_name = $request->field_name; 
                $data->$field_name = $request->field_val;
                
                
                $data->save();
                
                  $log = new Log();
                  $log->log_desc = "The User ".Auth::user()->user_name .' Updated '.  $field_name . ' in  The Task ' . $data->task_title ;
                  $log->log_user_id = Auth::user()->id;
                  $log->log_task_id = $id;
                  $log->save();
            } 
            
             
            DB::commit(); 
             
             $task = Task::find($id);
             $data = view('admin.tasks.single_task',compact('task'))->render();
             
           if($request->field_name == 'task_category_id'  && $request->field_val !=  $cat_id) {
                 return response()->json(['options'=> 'no' ]); 
           }else {
                 return response()->json(['options'=>$data]);
           }
             
             
           
    } 
      
      
}
