<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\SubTask;
use App\Models\User;
use App\Models\Log;
use DataTables;
use DB;
use Validator;
use Auth;

class SubTasksController extends Controller
{
  public function index() {
       $datas = SubTask::orderBy('id','desc')->get();
       return view('admin.subtasks.index',compact('datas'));
   }

   public function create() {
     $users = User::all();
     $tasks = Task::all();
     return view('admin.subtasks.create',compact('users','tasks'));
  }

  public function store(Request $request) {


      // dd($request->all());
      try {
        $validator = Validator::make($request->all(),[
             // 'subtask_title' => 'required|string|max:60',
               'task_id' => 'required',
             // 'subtask_user_id' => 'required',
           //   'subtask_start_date' => 'required',
             // 'subtask_due_date' => 'required',
          ]);

          if ($validator->fails()) {
              return redirect()->route('admin.subtasks.create')->with(array('errors' => $validator->getMessageBag()));
          }
         DB::beginTransaction();
         $data = new SubTask();
         $data->subtask_title = $request->subtask_title;
         $data->task_id = $request->task_id;
         $data->subtask_user_id = $request->subtask_user_id;
         $data->subtask_added_by = Auth::user()->id;
         //$data->subtask_start_date = $request->subtask_start_date;
         $data->subtask_due_date = $request->subtask_due_date;
         $data->save();
         $log = new Log();
         $log->log_desc = "The User ".Auth::user()->user_name .' Add A New Sub Task ' . $data->subtask_title ;
         $log->log_user_id = Auth::user()->id;
         $log->log_subtask_id = $data->id;
         $log->save();
         DB::commit();
         $subtasks =SubTask::where('task_id' , $request->task_id )->get();
         $data = view('admin.tasks.todos',compact('subtasks'))->render();
         return response()->json(['options'=>$data]);
        // return redirect()->route('admin.subtasks')->with(['success' => 'Data Added Successfully']);
      }catch(Exception $e) {
          //return redirect()->route('admin.subtasks')->with(['error' => 'Something Wrong Happen']);
      }


  }
  public function edit(Request $request ) {
          $id     = $request->id;
          $data  = SubTask::find($id);
          $users = User::all();
          $tasks = Task::all();
          return view('admin.subtasks.edit', ['data' => $data,'id' => $id , 'users' => $users , 'tasks' => $tasks ]);
   }
  public function update(Request $request , $id) {
    try {
      $validator = Validator::make($request->all(),[
            'subtask_title' => 'required|string|max:60',
             'task_id' => 'required',
            'subtask_user_id' => 'required',
            'subtask_start_date' => 'required',
            'subtask_due_date' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->route('admin.subtasks.create')->with(array('errors' => $validator->getMessageBag()));
        }
       DB::beginTransaction();
             $data =SubTask::find($id);
             $data->subtask_title = $request->subtask_title;
             $data->task_id = $request->task_id;
             $data->subtask_user_id = $request->subtask_user_id;
             $data->subtask_start_date = $request->subtask_start_date;
             $data->subtask_due_date = $request->subtask_due_date;
             $data->save();
             $log = new Log();
             $log->log_desc = "The User ".Auth::user()->user_name .' Updated The Sub Task ' . $data->subtask_title ;
             $log->log_user_id = Auth::user()->id;
             $log->log_subtask_id = $id;
             $log->save();
             DB::commit();
            return redirect()->route('admin.subtasks')->with(['success' => 'Data Updated Successfully']);
          }catch(Exception $e) {
              return redirect()->route('admin.subtasks')->with(['error' => 'Something Wrong Happen']);
          }

 }
 public function delete(Request $request) {
       $id = $request->id;
       $data = SubTask::find($id);
       $log = new Log();
       $log->log_desc = "The User ".Auth::user()->user_name .' Deleted The Sub Task ' . $data->subtask_title ;
       $log->log_user_id = Auth::user()->id;
       $log->log_subtask_id = $id;
       $data->delete();
       $log->save();
       $msg = 'Data Deleted Successfully';
       return response()->json([
                  "status" =>  true,
                  "msg" => $msg
                  ],200);
      }

      public function updateStatus(Request $request) {
              $id   = $request->id;
              $data =SubTask::find($id);
              if($data->subtask_status == 0) {
                    $data->subtask_status = 1;
                    $log = new Log();
                    $log->log_desc = "The User ".Auth::user()->user_name .' Make The Sub Task ' . $data->subtask_title . ' Completed';
                    $log->log_user_id = Auth::user()->id;
                    $log->log_subtask_id = $id;

              }else {
                 $data->subtask_status = 0;
                 $log = new Log();
                 $log->log_desc = "The User ".Auth::user()->user_name .' Make The Sub Task ' . $data->subtask_title . ' InCompleted';
                 $log->log_user_id = Auth::user()->id;
                 $log->log_subtask_id = $id;

              }
              $data->save();
              $log->save();
      }
      
      public  function  taskresponsiple(Request $request)
      {
           $users = User::all();
           foreach($users as $user)
           {
               echo "<option value='$user->id'>".$user->user_name."</option>" ; 
           }
      }
      
      
}
