@extends('layouts.admin')
@section('css')
<!--  BEGIN CUSTOM STYLE FILE  -->
<link href="{{asset('assets/admin/assets/css/scrollspyNav.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('assets/admin/assets/css/components/custom-modal.css')}}" rel="stylesheet" type="text/css" />
@endsection

@section('content')
<!--  BEGIN CONTENT AREA  -->
<div id="content" class="main-content">
  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
          @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @include('admin.includes.alerts.success')
        @include('admin.includes.alerts.errors')

        <div class="alert alert-danger error" style="display:none;">

        </div>
        <div class="alert alert-success success" style="display:none;">

        </div>
       <div class="table-responsive mb-4 mt-4 images_view">
            <table id="categories" class="table table-hover" style="width:100%">
              <thead>
                  <tr>
                       <th>Category Name</th>
                       <th>Category Color</th>
                       <th>Actions</th>
                  </tr>
              </thead>
              <tbody>
              @if(!empty($datas))
                <?php foreach ($datas as $key => $data): ?>
                  <tr>
                    <td>{{$data->category_name}}</td>
                    <td><span style="background-color:{{$data->category_color}};width:50px;height:50px;display:inline-block" ></td>
                    <td>
                      <button class="btn btn-success btn-edit-category"  data-id=" {{ $data -> id }} " >   Edit  </button>
                      <a href="javascript:;" class="btn btn-danger" data-id="{{ $data->id }}" style="color:#fff;">delete</a>
                    </td>
                  </tr>
              <?php endforeach; ?>
                @endif
              </tbody>
              <tfoot>
                    <tr>
                        <th>Category name </th>
                        <th>Category Color </th>
                        <th class="invisible"></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

  </div>

  </div>
<!--  END CONTENT AREA  -->

<!-- Modal -->
<div class="modal fade" id="EditCategoryModal" tabindex="-1" role="dialog" aria-labelledby="EditCategoryModalLabel" aria-hidden="true">
 <div class="modal-dialog" role="document">
     <div class="modal-content edit_category_modal">

     </div>
 </div>
</div>
@endsection
@section('script')
<script>
$(document).ready(function () {
  $(document).on('click', '.btn-edit-category', function (event) {
    //  alert('hello');
    event.preventDefault();
                var id = $(this).data('id');

                  $.ajax({

                      type: "post",
                      url: "{{route('admin.categories.edit')}}", // need to create this post route
                      data: {id : id , _token : '{{ csrf_token() }}'},
                      cache: false,
                      success: function (data) {


                           $('#EditCategoryModal').modal('show');
                            $(".edit_category_modal").html(data);
                      },
                      error: function (jqXHR, status, err) {


                      },

                 });
  });

    // Delete Category

   $(document).on('click','.btn-danger' ,  function (e) {
           if (!confirm("Are You Sure You Will Delete This Record")) {
               e.preventDefault();
               return false;
           }
            var selector = $(this);
           var id = $(this).data('id');
           $.ajax({
               type: 'POST',
               url: '{{ route('admin.categories.delete') }}',
               data: {id: id, _token: '{{ csrf_token() }}'},
               success: function (data) {
                      if(data.status == true) {
                      selector.closest('tr').hide('slow');
                      $('.error').css('display','none');
                      $('.success').css('display','block');
                      $('.success').html(data.msg);
                    }else {
                      $('.error').css('display','block');
                      $('.success').css('display','none');
                      $('.error').html(data.msg);
                    }
                    //  toastr.success(data.msg);
               },
               error: function (data) {
                      toastr.error(data.msg);
               }
           });
       });
     });
</script>
@stop
