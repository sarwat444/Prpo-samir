<form id="edit-category" method="post" action="{{route('admin.categories.update',$category->id)}}"  enctype="multipart/form-data">
  @csrf
  <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"> Update Category </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <svg> ... </svg>
          </button>
    </div>
    <div class="modal_body">
     <div class="form-group">
       <label>Category Name</label>
       <input type="text" name="category_name" class="form-control" value="{{$category->category_name}}">
     </div>
     <div class="form-group">
       <label>Category Color</label>
        <input type="color" name="category_color" value="{{$category->category_color}}" class="form-control">
     </div>
     </div>
      <div class="modal-footer">
          <button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Discard</button>
          <button type="submit" class="btn btn-primary">Update</button>
      </div>

</form>
