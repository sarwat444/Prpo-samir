
  <div class="header">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container-fluid">
                  <a class="navbar-brand" href="#">Pripo</a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
            </div>
            <div class="btn-group float-end">
            <ul class="navbar-nav navbar-light">
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                     <i class="bi bi-plus-circle-fill"></i>
                  </a>
                  <ul class="dropdown-menu" id="links" aria-labelledby="navbarDropdownMenuLink">
                    <li><a class="dropdown-item" data-type="task_create" href="#">Task</a></li>
                    <li><a class="dropdown-item" data-type="project_create"  href="#">Project</a></li>
                     @if(Auth::user()->role == 1)
                      <li><a class="dropdown-item" data-type="user_create"  href="#">User</a></li>
                      @endif
                  </ul>
                </li>
              </ul>
                
                
            </div>
            <div class="btn-group float-end">
                <a href="#" class="dropdown-toggle text-decoration-none text-light" data-bs-toggle="dropdown">
                <!--<i class="bi bi-person-circle"></i>-->
                      <img src="{{asset('public/assets/images/users/'.auth()->user()->image)}}" style="width:30px;height:30px;" class="rounded-circle">
                <span> {{ Auth::user()->user_name  }}  </span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                   
                       <li><a href="#" class="dropdown-item" data-type="profile_update" id="update_profile"><i class="bi bi-lock-fill"></i> Update Profile </a></li>
                   
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li><a href="{{route('admin.logout')}}" class="dropdown-item"><i class="bi bi-box-arrow-right"></i> Sign out</a></li>
                </ul>
            </div>
            
            
            
            
            
          </div>
        </nav>
  </div>


  <!--  BEGIN MAIN CONTAINER  -->
  <div class="main-container" id="container">

      <div class="overlay"></div>
      <div class="search-overlay"></div>
