  <div class="card sort" @if(!empty($task->category->category_color)) style="background-color:{{$task->category->category_color}}" @endif >
                        <div class="card-contents">
                            <div class="top-bar">
                                <div class="row">
                                <div class="col-md-3">
                                  <p>{{!empty($task->category->category_name) ? $task->category->category_name :' ' }}</p>
                                </div>
                                <div class="col-md-4">
                                 <p> {{$task->completed_subtasks->count()}} /{{$task->subtasks->count()}}</p>
                                </div>
                                <div class="col-md-5">
                                  
                                          @if(!empty($task->responsible))
                                                 <img src="{{asset('public/assets/images/users/'.$task->responsible->image)}}" alt="member"><p>
                                                      Verantwortlich
                                                     {{--!empty($task->responsible->user_name) ? $task->responsible->user_name : ' '--}}
                                                     
                                                     </p>
                                            @endif

                                  </div>
                                </div>
                            </div>
                            <div class="middle-content">
                               <h3>{{$task->task_title}}</h3>
                                <div class="members">
                                     <ul>
                                         @if(!empty($task->responsible))
                                             <li>  <img src="{{asset('public/assets/images/users/'.$task->responsible->image)}}" alt="member"> </li>
                                         @endif
                                         @if(!empty($task->added_by))
                                             <li>  <img src="{{asset('public/assets/images/users/'.$task->added_by->image)}}" alt="member"> </li>
                                         @endif

                                         @php
                                              $teamids = \App\Models\TaskTeam::where('task_id' , $task->id)->pluck('user_id');
                                              $teams   =  \App\Models\User::whereIn('id',$teamids)->get();
                                         @endphp

                                          @if(!empty($teams))
                                              @foreach ($teams as $key => $team)
                                                <li><img src="{{asset('public/assets/images/users/'.$team->image)}}" alt="member"></li>
                                              @endforeach
                                           @endif

                                        <button class="btn btn-default btn-task-popup" data-id="{{$task->id}}" ><i class="bi bi-plus-circle"></i></button>
                                     </ul>

                                </div>
                            </div>
                            <div class="button-bar">
                                <div class="row">

                                     <div class="col-md-6">
                                      @if(!empty($task->added_by))
                                      <img src="{{asset('public/assets/images/users/'.$task->added_by->image)}}" alt="member">
                                      @endif
                                       <span> {{--!empty($task->added_by->user_name) ? $task->added_by->user_name :' ' --}} Erstellt von </span></div>
                                     <div class="col-md-6">
                                          <p>DeadLine</p>
                                         <p> {{ date('d.m.Y', strtotime($task->task_due_date));}} </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>