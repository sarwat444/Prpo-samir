<link href="{{asset('public/assets/admin/assets2/css/fm.selectator.jquery.css')}}" rel="stylesheet">
<script src="{{asset('public/assets/admin/assets2/js/fm.selectator.jquery.js')}}" ></script>
<link href="{{asset('public/assets/admin/plugins/flatpickr/flatpickr.css')}}" rel="stylesheet" type="text/css">
	<script src="{{asset('public/assets/admin/plugins/flatpickr/flatpickr.js')}}"></script>
	<link rel="stylesheet" type="text/css" href="{{asset('public/assets/admin/assets2/css/theme-checkbox-radio.css')}}">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" ref="stylesheet">
<script>
				var  CLS_MATERIAL_ICONS = "material-icons";
				var  CLS_DESCRIPTION = "description";
				var  CLS_BTN_REMOVE = "btn-remove";
				var  CLS_TASK = "task";
				var  CLS_UNSELECTABLE = "unselectable";
				var  CLS_CHECKBOX = "checkbox";
				var  CLS_BTN_DRAG = "btn-drag";

				// KC - KeyCode
				var  KC_BACKSPACE = 8;
				var  KC_ENTER = 13;
				var  KC_UP = 38;
				var  KC_DOWN = 40;
				var  KS_LEFT = 37;
				var  KS_RIGHT = 39;

				var  POS_DESCR = 2;
				var  POS_CHECKBOX = 1;
				var POS_DATE = 3 ;
				var  POST_SELECT = 4 ;

				var taskList = document.querySelector(".todo .task-container");
				var percentage = document.querySelector(".todo .percentage");
				var newTask = document.querySelector(".todo .new-task");



				function load() {
					/*
					var aTasks = [];
					var loadedString = localStorage.getItem("tasks");

					if (loadedString != null) {

						aTasks = JSON.parse(loadedString);
						for (let i = 0; i < aTasks.length; i++) {
							var descr = aTasks[i].description;
							var isComplete = aTasks[i].isComplete;
							var task = createNewTask(descr, isComplete);
							taskList.appendChild(task);
						}
					}
					*/
				}

				function save() {

					var aTasks = [];

					for (let i = 0; i < taskList.children.length; i++) {
						aTasks[i] = {
							isComplete: taskList.children[i].children[POS_CHECKBOX].state ,
							description: taskList.children[i].children[POS_DESCR].innerHTML,
							date : taskList.children[i].children[POS_DATE].value,
							resposiple : taskList.children[i].children[POST_SELECT].value

						};

					}

					//  for (let i = 0; i < aTasks.length; i++) {
					//         console.log(aTasks[i]);
					//   }

					$(document).ready(function () {
					var task_id = $("#task_id").val();
					console.log(aTasks[ aTasks.length - 1].description + '     ' + aTasks[ aTasks.length - 1].date + '   '+ aTasks[ aTasks.length - 1].TaskResponsiple);

					$.ajax({

									type: "POST",
									url:   '{{route('admin.subtasks.store')}}',   // need to create this post route
									data: {subtask_title: aTasks[ aTasks.length - 1].description ,  subtask_due_date: aTasks[ aTasks.length - 1].date , task_id : task_id  , _token: '{{ csrf_token() }}'},
									cache: false,
									success: function (data) {

										//   $('#shuffle').html('');
										//   $('#shuffle').html(data.options);
																$('#task'+task_id).html('');
																$('#task'+task_id).html(data.options);

									},
									error: function (jqXHR, status, err) {


									},
					});





					});

					localStorage.setItem("tasks", JSON.stringify(aTasks));


				}

				function updatePercentage() {
					var taskCount = taskList.children.length;
					var completedTaskCount = 0;

					for (let i = 0; i < taskCount; i++) {
						var cb = taskList.children[i].children[POS_CHECKBOX];
						completedTaskCount += cb.state;
					}

					if (taskCount == 0) {
						percentage.innerHTML = "";
					} else {
						percentage.innerHTML = Math.round((completedTaskCount/taskCount)*100) + "%";
					}
				}

				function setCheckBoxState(checkBox, isDone) {
					checkBox.state = isDone;
					if (isDone) {
						checkBox.innerHTML = "check_box";
					} else {
						checkBox.innerHTML = "check_box_outline_blank";
					}
				}


				function updateStyle(task) {
					if (task.children[POS_CHECKBOX].state) {
						task.classList.add("completed");
					} else {
						task.classList.remove("completed");
					}
				}

				function getCheckBoxState(checkBox) {
					return checkBox.state;
				}

				function removeTask(task) {
					console.log(task);
					task.parentElement.removeChild(task);
					updatePercentage();
				}

				/* Function from stackoverflow */
				function moveCursorToEnd(el) {
					el.focus();
					if (typeof window.getSelection != "undefined"
							&& typeof document.createRange != "undefined") {
						var range = document.createRange();
						range.selectNodeContents(el);
						range.collapse(false);
						var sel = window.getSelection();
						sel.removeAllRanges();
						sel.addRange(range);
					} else if (typeof document.body.createTextRange != "undefined") {
						var textRange = document.body.createTextRange();
						textRange.moveToElementText(el);
						textRange.collapse(false);
						textRange.select();
					}
				}

				function focusOnLastDescr(taskList) {
					if (taskList.children.length > 0) {
						var lastDescr = taskList.lastChild.children[POS_DESCR];
						moveCursorToEnd(lastDescr);
					}
				}

				function focusOnPrevDescr(task) {
					if (task.previousSibling !== null) {
						var prev = task.previousSibling.children[POS_DESCR];
						moveCursorToEnd(prev);
					}
				}

				function createNewTask(text, isComplete) {


					var task = document.createElement("li");
					task.className = CLS_TASK;

					var dragBtn = document.createElement("i");
					dragBtn.className = CLS_MATERIAL_ICONS + " " + CLS_UNSELECTABLE + " " + CLS_BTN_DRAG;
					dragBtn.innerHTML = "drag_indicator";

					// var checkBox = document.createElement("i");
					// setCheckBoxState(checkBox, isComplete);
					// checkBox.className = CLS_MATERIAL_ICONS + " " + CLS_UNSELECTABLE + " " + CLS_CHECKBOX;
						var checkBox = document.createElement("input");
						checkBox.type="checkbox" ;
				checkBox.className = "change_status taskched";

					// checkBox.onclick = function() {
					//     setCheckBoxState(checkBox, !getCheckBoxState(checkBox));
					//     updateStyle(task);
					//     updatePercentage();
					// };

					var descr = document.createElement("span");
					descr.className = CLS_DESCRIPTION;
					descr.innerHTML = text;
					descr.setAttribute("contenteditable", "true");
					descr.onkeydown = function(e) {
						if ((e.keyCode === KC_BACKSPACE) && ((e.target.innerHTML === "<br>") || (e.target.innerText.length === 0))) {
							if (task.previousSibling !== null) {
								focusOnPrevDescr(task);
								removeTask(task);
							}
							/* Do not delete last character from selected task */
							return false;
						}

						if ((e.keyCode === KC_ENTER) & (e.shiftKey === false)) {
							save() ;
							let t = createNewTask("", false);
							task.after(t);
							t.getElementsByClassName(CLS_DESCRIPTION)[0].focus();
							updatePercentage();
							return false;
						}

						if ((task.previousSibling !== null) && (e.keyCode === KC_UP) && (e.shiftKey === false)) {
								task.previousSibling.children[POS_DESCR].focus();
								return false;
						}

						if ((task.nextSibling !== null) && (e.keyCode === KC_DOWN) && (e.shiftKey === false)) {
								task.nextSibling.children[POS_DESCR].focus();
								return false;
						}
					}

					var  date  = document.createElement("input") ;
					date.type ="date" ;
					date.className = "date" ;

					var responsiple = document.createElement("select") ;
					responsiple.className ="TaskResponsiple" ;
					responsiple.name  ="TaskResponsiple" ;


					var removeBtn = document.createElement("i");
					removeBtn.className = CLS_MATERIAL_ICONS + " " + CLS_BTN_REMOVE + " " + CLS_UNSELECTABLE;
					removeBtn.innerHTML = "remove_circle";
					removeBtn.onclick = function() {

						removeTask(task);
					};

					task.appendChild(dragBtn);
					task.appendChild(checkBox);
					task.appendChild(descr);
					task.appendChild(date);
					task.appendChild(responsiple);
					task.appendChild(removeBtn);

					updateStyle(task);

					return task;



				}


				newTask.onkeydown = function(e) {
					// Enter, Shift, Backspace, Up etc
					var keyCodeIsSpecial = e.keyCode <= 47 | e.keyCode === 91 | e.keyCode === 144 | e.keyCode === 145;

					if ((e.keyCode === KC_BACKSPACE) && (e.target.value === "")) {
						return false;
					} else if (!keyCodeIsSpecial){

						let task = createNewTask("", false);
						if (taskList.children.length === 0) {
							taskList.appendChild(task);
						} else {
							taskList.lastChild.after(task);

						}
						task.children[POS_DESCR].focus();
						updatePercentage();
					}
				}


				var firstStart =
					(localStorage.getItem("first_start") === null) ||
					(localStorage.getItem("first_start") === "true");

				if (firstStart) {


					save();
					localStorage.setItem("first_start", "false");
				} else {
					load();
				}



				updatePercentage();

				var sortable = Sortable.create(taskList, {
					handle: ".btn-drag",
					animation: 100,
					chosenClass: "todo-chosen-task",
					ghostClass: "todo-ghost-task",
				});

										</script>


							</div>
						</div>
					</form>
					</div>


				</div>
				<!-- Sidebar -->
				</header>
				<!--Main Navigation-->

				<!--Main layout-->
				<main style="margin-top: 58px;">
				<div class="container pt-4"></div>
				</main>
				<!--Main layout-->
				<!--End Sidebar -->


<script>

$(document).ready(function(){



 "use strict";

	 /* Start  ToDo Addition */
	 let wrapper = document.querySelector('.wrapper') ;
	 let newtodo = document.querySelector('.todo_name') ;
	 let todo_date = document.querySelector('.todo_date') ;
	 let todo_responsible = document.querySelector('.todo_responsible') ;
	 let addtodo = document.querySelector('.add_todo') ;
	 let todo = []  ;

	 // addtodo.addEventListener('click'  , ()=>{
	 //  if( newtodo.value !=''){
	 //   //   console.log('not empty');
	 //
	 //  //alert(todo_date.value);
	 //      todo.push([newtodo.value , todo_date.value  , todo_responsible.value ] ) ;
	 //
	 //  //Append Values
	 //
	 //  let newtodolist = document.createElement('div')  ;
	 //   newtodolist.className = 'item' ;
	 //         for(let i=0; i<todo.length;i++)
	 //         {
	 //              newtodolist.innerHTML = '<p>'+newtodo.value +'</p>'+ '<ul>'+'<li>'+todo_date.value + '</li><li>'  +  todo_responsible.value +'</li></ul>';
	 //              wrapper.appendChild(newtodolist) ;
	 //
	 //         }
	 //
	 //       if(todo.length > 0 )
	 //       {
	 //
	 //                  let item =  document.querySelectorAll('.item') ;
	 //                  let checkicone = document.createElement('i');
	 //                   checkicone.className = 'bi bi-check-circle' ;
	 //
	 //
	 //                  let trush = document.createElement('i');
	 //                   trush.className = 'bi bi-trash  trash' ;
	 //
	 //
	 //              for(let  j=0 ; j<item.length ; j++ )
	 //               {
	 //
	 //                    item[j].appendChild(checkicone) ;
	 //                    item[j].appendChild(trush) ;
	 //
	 //
	 //                   trush.addEventListener('click',  ()=>{
	 //
	 //                       trush.parentNode.remove();
	 //
	 //                   })
	 //               }
	 //       }
	 //
	 //
	 //       }
	 //
	 // });



	 // $('.trash').on('click',function(){
	 //     // alert($(this).closest('.item').data('id'));
	 //     // $(this).closest('.item').remove();
	 //
	 //
	 // });

	 $('.trash').on('click',function(){

					if (!confirm("Are You Sure You Will Delete This Record")) {
						e.preventDefault();
						return false;
				}

			 var id = $(this).closest('.item').data('id');
			 $.ajax({
						type: 'POST',
						url: '{{ route('admin.subtasks.delete') }}',
						data: {id: id, _token: '{{ csrf_token() }}'},
						success: function (data) {
								 $(this).closest('.item').remove();
						}
				});
					$(this).closest('.item').remove();
		});

		$('.change_status').on('click',function(){
			 var id = $(this).closest('.item').data('id');
				$.ajax({
						 type: 'POST',
						 url: '{{ route('admin.subtasks.update_status') }}',
						 data: {id: id, _token: '{{ csrf_token() }}'},
						 success: function (data) {

						 }
				 });

		 });
	 // add subtask
	 $('#add_subtask').on('click',function(){
				//  alert('hello');
				 event.preventDefault();
				 var subtask_title = $("#subtask_title").val();
				 var subtask_user_id = $("#subtask_user_id").find(':selected').attr('data-id');
				 var subtask_start_date = $("#subtask_start_date").val();
				 var subtask_due_date = $("#subtask_due_date").val();
				 var task_id = $("#task_id").val();
			 //  alert(subtask_title  + '  '+subtask_user_id  + '  '+subtask_start_date  + '  '+subtask_due_date  + '  '+ task_id  + '  ');
					 $.ajax({

							 type: "post",
							 url: "{{route('admin.subtasks.store')}}", // need to create this post route
							 data: {subtask_title : subtask_title , subtask_user_id : subtask_user_id , subtask_start_date:subtask_start_date , subtask_due_date:subtask_due_date , task_id:task_id, _token : '{{ csrf_token() }}'},
							 cache: false,
							 success: function (data) {
									 //console.log('done');
									 $('.wrapper').html(data.options);
							 },
							 error: function (jqXHR, status, err) {
							 },
					});

});



		$('#edit_subtask .target').on('change',function() {

							 // alert('changed!');
							 var task_id = $('#task_id').val();
							 var field_name  = $(this).data('name');
							 var field_val = $(this).val();
							 $.ajax({
							 type: "post",
							 url: "{{route('admin.tasks.update_field')}}", // need to create this post route
							 data: {task_id : task_id  , field_name : field_name , field_val : field_val , _token : '{{ csrf_token() }}'},
							 cache: false,
							 success: function (data) {
								 //  console.log('done');
								 //  $('.wrapper').html(data.options);
										if(data.options == 'no') {
										 $('#task'+task_id).html('');
											$('#task'+task_id).html(data.options2);
									 }else {
										 $('#task'+task_id).html('');
											$('#task'+task_id).html(data.options);
									 }

							 },
							 error: function (jqXHR, status, err) {
							 },
		});

		});

});




</script>
		<script>

						 var show = true;

							function showCheckboxes() {
									var checkboxes =
											document.getElementById("checkBoxes");

									if (show) {
											checkboxes.style.display = "block";
											show = false;
									} else {
											checkboxes.style.display = "none";
											show = true;
									}
							}
			 </script>
							<script type="text/javascript">
				$(function () {
					var $activate_selectator = $('#activate_selectator4');
					$activate_selectator.click(function () {
						var $select = $('#select3');
						if ($select.data('selectator') === undefined) {
							$select.selectator({
								showAllOptionsOnFocus: true,
								useDimmer: true,
								searchFields: 'value text subtitle right'
							});
							$activate_selectator.val('destroy');
						} else {
							$select.selectator('destroy');
							$activate_selectator.val('activate');
						}
					});
					$activate_selectator.trigger('click');
				});
			</script>

					 <script>
					 /*
												var counter = 1; //limits amount of transactions
															 function addElements() {
																	 if (counter < 5) //only allows 4 additional transactions
																	 {

																			 let todo_wrap =  document.getElementById('todo_wrap') ;

																			 let row = document.createElement('div');
																			 row.id = 'row';
																			 row.className = 'row';
																			 todo_wrap.appendChild(row);


																			 let cols = document.createElement('div');
																			 cols.className= 'col-md-5 subtaskform';
																			 row.appendChild(cols);


																			 let label = document.createElement('label');
																			 label.className ='new-control new-checkbox new-checkbox-rounded checkbox-success' ;
																			 cols.appendChild(label);



																			 let checkbox = document.createElement('input');
																			 checkbox.id='subtask_title'+counter;
																			 checkbox.type = 'checkbox ';
																			 checkbox.className ='new-control-input' ;
																			 label.appendChild(checkbox);


																			 let span = document.createElement('span');
																			 span.className ='new-control-indicatort' ;
																			 label.appendChild(span);


																			 let input = document.createElement('input');
																			 input.id='subtask_title'+counter;
																			 input.type = 'text ';
																			 input.name= 'subtask_title';
																			 input.className ='subtask_title' ;
																			 cols.appendChild(input);





																			let cols2 = document.createElement('div');
																			 cols2.className= 'col-md-3 subtaskform';
																			 row.appendChild(cols2);

																			 let date = document.createElement('input');
																			 date.type = 'text';
																			 date.name= 'subtask_due_date';

																			 date.className ='dateTimeFlatpickr form-control flatpickr flatpickr-input' ;
																			 cols2.appendChild(date);


																	 }

																	 counter++
																	 if (counter >= 6) {
																			 alert("You have reached the maximum transactions.")
																	 }
															 }
												*/
										</script>



					 <script>
													$(document).ready(function(){
													 var f2 = flatpickr(document.getElementsByClassName('dateTimeFlatpickr'), {
													 enableTime: true,
													 dateFormat: "d.m.Y  H:i",
													 });

													})

											</script>

											<script>

													window.addEventListener('load', (event) => {
														console.log('The page has fully loaded');
													});


											</script>


				});


</script>

	<style>
#select1,
#select1_ajax {
	width: 250px;
}
#select2,
#select2_ajax,
#select3,
#select3_ajax,
#select5,
#select5_ajax,
#select6 {
	width: 100%;
	height: 36px;
}
#select4,
#select4_ajax {
	width: 350px;
	height: 50px;
}
.option_one,
.option_two,
.option_three,
.option_four,
.option_five,
.option_six,
.option_seven,
.option_eight,
.option_nine,
.option_ten,
.option_eleven,
.option_twelve,
.option_thirteen,
.option_fourteen {
}
.group_one,
.group_two,
.group_three {
}

</style>


<!--Main Navigation-->
<header>
<!-- Sidebar -->
<div id="sidebarMenu" class="collapse d-lg-block sidebar collapse bg-white">
<form id="edit_subtask" action="{{route('admin.tasks.update',$task->id)}}" method="POST" enctype="multipart/form-data">
@csrf

<input type="hidden" name="task_id" value="{{$task->id}}" id="task_id">
<div class="position-sticky">
				<button id="dismiss" class="dismiss" type="button">
				<span aria-hidden="true">&times;</span>
			</button>
 <div class="main-tasks">



			 <div class="task-details">

				 <div class="form-group">
										<div class="col-md-10">
										 <div class="main_tasks_header">
												<input type="text" name="task_title" value="{{$task->task_title}}" data-name="task_title" class="target form-control">
										 </div>
										 </div>

									 <div class="row">
										<div class="col-md-3">
												<lable class="control-label">Assign</lable>
										</div>

										 <div class="col-md-7">
											 <select name="task_responsible"  data-name="task_responsible" class="form-control custom-select target">
												@foreach ($users as $key => $user)
													<option value="{{$user->id}}" @if($task->task_responsible == $user->id ) selected @endif > {{$user->user_name }} </option>
												@endforeach
										 </select>
									</div>

							</div>
				 </div>

					<div class="form-group">
							<div class="row">
												<div class="col-md-3">
													 <lable class="control-label">Team Members</lable>
												</div>

									<div class="col-md-7">
										 <select id="select3" name="select3" class="target" multiple data-name="teams_id">

																 @php
																						 $team_ids = \App\Models\TaskTeam::where('task_id' , $task->id)->pluck('user_id');
																						 $team_ids2 = json_decode($team_ids);
																				 @endphp
																					@if(!empty($users))
																						 @foreach ($users as $key => $user)
																		 <option  id="{{$key}}"  value="{{$user->id}}" name="teams_id[]" class="option_one"  data-left="{{asset('public/assets/images/users/'.$user->image)}}"  @if(in_array($user->id , $team_ids2)) selected  @endif >    {{$user->user_name}}</option>
																			@endforeach
																	 @endif

							</select>
							<input value="activate" id="activate_selectator4" type="button">
							<script type="text/javascript">
								$(function () {
									var $activate_selectator = $('#activate_selectator4');
									$activate_selectator.click(function () {
										var $select = $('#select3');
										if ($select.data('selectator') === undefined) {
											$select.selectator({
												showAllOptionsOnFocus: true,
												useDimmer: true,
												searchFields: 'value text subtitle right'
											});
											$activate_selectator.val('destroy');
										} else {
											$select.selectator('destroy');
											$activate_selectator.val('activate');
										}
									});
									$activate_selectator.trigger('click');
								});
							</script>
									</div>
							</div>
				 </div>



			 <div class="form-group">
							<div class="row">
												<div class="col-md-3">
													 <lable class="control-label">DeadLine</lable>
												</div>

									<div class="col-md-7">

												 <div class="datepicker">
												 <input  type="text" value="{{date('d.m.Y', strtotime($task->task_due_date))}}"  class="dateTimeFlatpickr form-control flatpickr flatpickr-input target" data-name="task_due_date"  name="task_due_date"  placeholder="DeadLine">
											 </div>
									</div>
							</div>
			 </div>

		 <div class="form-group">
							<div class="row">
												<div class="col-md-3">
													 <lable class="control-label">Project</lable>
												</div>
									<div class="col-md-7">

														 <select name="task_category_id" class="custom-select form-control target" data-name="task_category_id">
																	 @foreach ($cats as $key => $cat)
																		 <option value="{{$cat->id}}" @if($task->task_category_id == $cat->id ) selected @endif > {{$cat->category_name }} </option>
																	 @endforeach
														 </select>
								</select>
									</div>
							</div>
		 </div>

					<div class="form-group">
						 <div class="row">
												<div class="col-md-3">
													 <lable class="control-label">Description</lable>
												</div>
									<div class="col-md-7">


											<textarea  class="form-control target" data-name="task_desc" >{{$task->task_desc}}</textarea>
								</select>
									</div>
							</div>
					</div>

		 </div>
		 <div class="sub_tasks2">
				 <div class="sub_tasks_header">
						<h3><i class="bi bi-calendar2-plus"></i> Sub Tasks</h3>
				 </div>
						 <div class="col-md-10">
								<div class="container">
									<ul class="todo box-shadow">
											<li class="title">

													<span class="percentage"></span>
											</li>
											<div class="task-container">

												@foreach($task->subtasks as $subtask)

													<li @if($subtask->subtask_status != 0) class="task completed"   @else class="task"  @endif>
														 <i class="material-icons unselectable btn-drag">drag_indicator</i>

															<input class="taskched change_status" data-id="{{$subtask->id}}" type="checkbox" @if($subtask->subtask_status != 0) checked  @else  ' '  @endif >


													<span class="description desc" data-id="{{$subtask->id}}" contenteditable="true">{{$subtask->subtask_title}}</span>
													<input type="date" class="date dte" data-id="{{$subtask->id}}" value="{{$subtask->subtask_due_date}}">

													<select class="TaskResponsiple" name="TaskResponsiple" data-id="{{$subtask->id}}" >

																	@foreach ($users as $key => $user)
																			 <option value="{{$user->id}}" @if($subtask->subtask_user_id == $user->id ) selected @endif > {{$user->user_name }} </option>
															 @endforeach

													</select>


													<i class="material-icons btn-remove unselectable" data-id="{{$subtask->id}}">remove_circle</i></li>



											@endforeach
											</div>
											<li class="create">
													<i class="material-icons unselectable">add</i>
													<input class="new-task" contenteditable="true" placeholder="New task">
											</li>
											<li class="bottom"></li>
									</ul>
							</div>

					 </div>
		</div>

<script>

$(document).ready(function(){

$(document).on('keyup' , '.desc',function() {
	 var subtask_id=  $(this).data('id');
	 var desc_val = $(this).text();


//	  alert(desc_val);
	 $.ajax({
	 type: "POST",
	 url: '{{route('admin.subtasks.updatefielddd')}}', // need to create this post route
	 data: {subtask_id : subtask_id  ,  desc_val : desc_val , _token : '{{ csrf_token() }}'},
	 cache: false,
	 success: function (data) {
			//console.log('done');

	 },
	 error: function (jqXHR, status, err) {
	 },
});

});




$(document).on('change' , '.date',function() {
		 var subtask_id=  $(this).data('id');
		 var date_val = $(this).val();
//	  alert(date_val);
		 $.ajax({
		 type: "POST",
		 url: '{{route('admin.subtasks.updatefielddd')}}', // need to create this post route
		 data: {subtask_id : subtask_id  ,  date_val : date_val , _token : '{{ csrf_token() }}'},
		 cache: false,
		 success: function (data) {
				// console.log('done');

		 },
		 error: function (jqXHR, status, err) {
		 },
});

});

$(document).on('change' , '.TaskResponsiple',function() {
			 var subtask_id=  $(this).data('id');
			 var resp_val = $(this).val();
	//  alert(resp_val);

			 $.ajax({
			 type: "POST",
			 url: '{{route('admin.subtasks.updatefielddd')}}', // need to create this post route
			 data: {subtask_id : subtask_id  ,  resp_val : resp_val , _token : '{{ csrf_token() }}'},
			 cache: false,
			 success: function (data) {
					// console.log('done');

			 },
			 error: function (jqXHR, status, err) {
			 },
});

	});


	$('.change_status').on('click',function(){
	 var id = $(this).data('id');
		var dta = $(this).text();
	 //alert(dta);
		//
		$.ajax({


				 type: 'POST',
				 url: '{{ route('admin.subtasks.update_status') }}',
				 data: {id: id, _token: '{{ csrf_token() }}'},
				 success: function (data) {

				 }
		 });

 });


 $(document).on('change', '.taskched', function (event) {
												if(jQuery(this).prop("checked")){
												 jQuery(this).parents('li').addClass('completed');
												}else
												{
												 jQuery(this).parents('li').removeClass('completed');
												}
										});

					 $(document).on('click', '.btn-remove', function (event) {
												 $(this).closest('.task').remove();
                         var id = $(this).data('id');
												 $.ajax({


															type: 'POST',
															url: '{{ route('admin.subtasks.delete') }}',
															data: {id: id, _token: '{{ csrf_token() }}'},
															success: function (data) {

															}
													});

										});




});
</script>
