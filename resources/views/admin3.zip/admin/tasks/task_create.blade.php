
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            @include('admin.includes.alerts.success')
            @include('admin.includes.alerts.errors')
           <div class="row layout-top-spacing">
             <div id="basic" class="col-lg-12 layout-spacing">
              <div class="statbox widget box box-shadow">
                  <div class="widget-header">
                       <button id="dismiss" class="dismiss" type="button">
                         <span aria-hidden="true">&times;</span>
                       </button>
                  </div>
              <div class="widget-content widget-content-area">
                <form id="create-category" action="{{route('admin.tasks.store')}}" method="POST" enctype="multipart/form-data">
                    @csrf
                   <div class="form-group">
                       
                     <label>Task Title</label>
                      <input type="text" name="task_title" class="form-control">
                      
                   </div>
                   <div class="form-group">
                     <label>Task Description</label>
                      <textarea type="text" name="task_desc" class="form-control"> </textarea>
                   </div>
                   <div class="form-group">
                     <label>Task Category</label>
                     <select class="selectpicker form-control" id="task_category_id" name="task_category_id" data-size="5" >

                             <option value="">Select Category</option>

                           @foreach ($categories as $key => $category)


                                  <option value="{{$category->id}}"> {{$category->category_name }} </option>

                            @endforeach

                      </select>
                   </div>

                   <div class="form-group">
                     <label>Responsible For Task</label>
                     <select class="selectpicker form-control" id="task_responsible" name="task_responsible" data-size="5" >

                          <option value="">Select User</option>

                           @foreach ($users as $key => $user)
                             <option value="{{$user->id}}"> {{$user->user_name }} </option>
                           @endforeach

                      </select>
                   </div>
                   <div class="form-group">
                     <label>Team Members</label>
               
                      
                      <div class="multipleSelection">
                                           <div class="selectBox"
                                               onclick="showCheckboxes()">
                                               <select class="form-control select2 select_members" >
                                                   <option>Team Members </option>
                                               </select>
                                               <div class="overSelect"></div>
                                           </div>

                                           <div id="checkBoxes">

                                             @if(!empty($users))

                                             @foreach($users as $key =>$user)
                                               <label for="{{$key}}">
                                                   <input type="checkbox" id="{{$key}}"  value="{{$user->id}}" name="teams_id[]" checked/>
                                                     {{$user->user_name}}
                                               </label>

                                               @endforeach

                                               @endif

                                           </div>
                    </div>
                      </div>                 
           
                   <div class="form-group">
                     <label> Start Date </label>
                     <input type="date" class="form-control selectdate" name="task_start_date" value="">
                   </div>
                   <div class="form-group">
                     <label> Due Date </label>
                     <input type="date" class="form-control selectdate" name="task_due_date" value="">
                   </div>

                  <button type="submit" class="btn btn-primary save_task"> Save Task </button>

              </form>
            <div class="code-section-container show-code">
             <div class="code-section text-left">
           </div>
              </div>
        </div>
        </div>
        </div>
        </div>
        <script>
            
                        var show = true;

               function showCheckboxes() {
                   var checkboxes =
                       document.getElementById("checkBoxes");

                   if (show) {
                       checkboxes.style.display = "block";
                       show = false;
                   } else {
                       checkboxes.style.display = "none";
                       show = true;
                   }
               }
        </script>